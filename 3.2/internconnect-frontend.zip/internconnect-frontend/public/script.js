const jsContent = `
function showMessage() {
    document.getElementById("output").innerHTML = "Hello! You clicked the button.";
}`;